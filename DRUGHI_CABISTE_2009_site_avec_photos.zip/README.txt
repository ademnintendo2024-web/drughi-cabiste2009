DRUGHI CABISTE 2009 — site personnalisé avec vos photos

DANS CE DOSSIER
- index.html : page d'accueil, présentation, blog, galerie et contact
- style.css : design noir/jaune adapté aux mobiles
- images/ : logo et photos que vous avez fournies

PHOTO D'ACCUEIL
La grande photo de tribune avec fumée jaune/noire et la bâche DRUGHI est utilisée en arrière-plan.

APERÇU SUR UN ORDINATEUR
1. Décompressez le ZIP.
2. Ouvrez le dossier.
3. Double-cliquez sur index.html.
Les images doivent rester dans le dossier images/ pour s'afficher.

MISE EN LIGNE
Ce site statique peut être publié gratuitement avec Netlify (par exemple, via le déploiement manuel du dossier du site après extraction) ou GitHub Pages. Vous devrez créer un compte et suivre les étapes d'hébergement. Une adresse publique est fournie; un nom de domaine personnalisé est facultatif.

MISES À JOUR
Pour une petite modification, on peut modifier index.html (texte/liens) ou style.css (couleurs/design), puis republier le dossier mis à jour sur le service d'hébergement. Les changements ne sont pas automatiquement publiés juste en modifiant les fichiers sur votre téléphone.

À NOTER
- Le site n'apparaît pas forcément immédiatement dans les résultats Google après sa publication. L'indexation peut prendre du temps.
- Le blog est une section d'accueil avec des cartes d'articles de démonstration; il ne comprend pas encore un panneau d'administration pour publier sans toucher aux fichiers.
- Vérifiez les droits d'utilisation des photos et des logos avant la publication publique.
